package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class controller {

	public controller() {
		// TODO Auto-generated constructor stub
	}
	@RequestMapping("/newproduct")
	public String newproduct()
	{
		return "/components/newproduct";
	}
	@RequestMapping("/detail")
	public String detail()
	{
		return "/components/detail";
	}
	@RequestMapping("/detailmanager")
	public String detailmanager()
	{
		return "/components/detailmanager";
	}
	@RequestMapping("/editproduct")
	public String editproduct()
	{
		return "/components/editproduct";
	}
	@RequestMapping("/manager")
	public String manager()
	{
		return "/components/manager";
	}
	@RequestMapping("/cart")
	public String cart()
	{
		return "/components/cart";
	}
	@RequestMapping("/")
	public String index()
	{
		return "index";
	}
}
